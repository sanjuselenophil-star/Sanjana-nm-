# PocketSmart AI

A budget-aware AI recommendation assistant based on the supplied project specification.

## Features

- User registration, login, logout and JWT authentication
- Home Interior Budget Planner
- Party Budget Planner
- Jewelry Budget Planner
- Optional outfit image upload for Jewelry Planner
- Gemini-powered recommendations
- SQLite database for users and recommendation history
- Jinja2 HTML frontend
- Recommendation history
- Mock product/vendor catalog for Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO-style links
- Fallback recommendations when Gemini is unavailable

## Project structure

```text
PocketSmartAI/
├── app/
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── auth.py
│   ├── dependencies.py
│   ├── routers/
│   │   ├── auth.py
│   │   ├── planners.py
│   │   └── pages.py
│   ├── services/
│   │   ├── gemini_service.py
│   │   ├── recommendation_service.py
│   │   └── catalog_service.py
│   ├── templates/
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── login.html
│   │   ├── register.html
│   │   ├── dashboard.html
│   │   ├── history.html
│   │   ├── home_planner.html
│   │   ├── party_planner.html
│   │   └── jewelry_planner.html
│   └── static/
│       ├── css/style.css
│       └── js/app.js
├── uploads/
├── data/
├── .env.example
├── .gitignore
├── requirements.txt
└── run.py
```

## 1. Create the environment

Windows:

```powershell
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

## 2. Install packages

```bash
pip install -r requirements.txt
```

## 3. Configure Gemini

Copy:

```text
.env.example
```

to:

```text
.env
```

Then put your API key in:

```env
GEMINI_API_KEY=your_key_here
```

The model is configurable:

```env
GEMINI_MODEL=gemini-1.5-flash
```

If your Google account exposes a different current Gemini model, change only `GEMINI_MODEL`; the application code does not need to change.

## 4. Run

```bash
python run.py
```

Open:

```text
http://127.0.0.1:8000
```

## 5. API endpoints

Authentication:

- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/auth/me`

Planner APIs:

- `POST /api/planners/generate-home`
- `POST /api/planners/generate-party`
- `POST /api/planners/generate-jewelry`

History:

- `GET /api/planners/history`
- `GET /api/planners/history/{id}`

Health:

- `GET /api/health`

## Notes

The supplied project description mentions external platforms such as Amazon, Flipkart, IKEA, Swiggy, Zomato and OYO. This starter implementation intentionally uses a local mock catalog and generated search links instead of pretending to have access to private third-party APIs.

For production use, replace `catalog_service.py` with official APIs, affiliate feeds, or another licensed product-data provider.
