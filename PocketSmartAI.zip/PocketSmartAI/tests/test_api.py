# Basic manual/API test notes.
#
# Start the server:
#     python run.py
#
# Then use Postman:
#
# POST http://127.0.0.1:8000/api/auth/register
# Body -> raw -> JSON:
# {
#   "name": "Test User",
#   "email": "test@example.com",
#   "password": "password123"
# }
#
# Copy access_token from the response.
#
# POST http://127.0.0.1:8000/api/planners/generate-home
# Headers:
# Authorization: Bearer YOUR_TOKEN
#
# Body:
# {
#   "budget": 50000,
#   "rooms": ["Living Room", "Bedroom"],
#   "items": ["lights", "fan", "dining table"],
#   "style": "Modern",
#   "priorities": "value for money"
# }
