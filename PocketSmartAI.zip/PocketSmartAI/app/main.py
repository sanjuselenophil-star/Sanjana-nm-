from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .database import Base, engine
from .routers import auth, planners, pages

Path("data").mkdir(exist_ok=True)
Path("uploads").mkdir(exist_ok=True)

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="PocketSmart AI",
    description="Smart Budget & Recommendation Assistant",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="app/static"), name="static")
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

app.include_router(pages.router)
app.include_router(auth.router)
app.include_router(planners.router)


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "service": "PocketSmart AI"
    }


@app.get("/api/session-info")
def session_info():
    return {
        "message": "Use /api/auth/me to retrieve the authenticated user."
    }


@app.get("/api/session-data")
def session_data():
    return {
        "message": "Session personalization is represented through authenticated user history."
    }


@app.get("/api/recommendations-details")
def recommendation_details():
    return {
        "message": "Use the planner endpoints to generate detailed recommendations."
    }
