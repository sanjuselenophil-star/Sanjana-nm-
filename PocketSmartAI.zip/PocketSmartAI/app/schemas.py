from typing import List, Optional
from pydantic import BaseModel, Field, EmailStr


class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(min_length=6, max_length=100)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class HomeRequest(BaseModel):
    budget: float = Field(gt=0)
    rooms: List[str] = Field(default_factory=list)
    items: List[str] = Field(default_factory=list)
    style: str = "Modern"
    priorities: str = "value for money"


class PartyRequest(BaseModel):
    budget: float = Field(gt=0)
    guests: int = Field(gt=0, le=10000)
    event_type: str = "Birthday"
    venue: str = "Home"
    food_preference: str = "Mixed"
    city: str = ""
    priorities: str = "balanced spending"


class JewelryRequest(BaseModel):
    budget: float = Field(gt=0)
    occasion: str = "Party"
    style: str = "Elegant"
    metal: str = "Any"
    outfit_description: str = ""
    image_filename: Optional[str] = None


class RecommendationItem(BaseModel):
    category: str
    name: str
    description: str
    price: float
    platform: str
    url: str


class RecommendationResponse(BaseModel):
    planner: str
    budget: float
    summary: str
    allocations: dict
    recommendations: List[RecommendationItem]
