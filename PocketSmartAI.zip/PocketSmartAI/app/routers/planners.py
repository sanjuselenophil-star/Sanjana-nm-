import json
import os
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from ..database import get_db
from ..dependencies import get_current_user
from ..models import User, RecommendationHistory
from ..schemas import HomeRequest, PartyRequest, JewelryRequest
from ..services.catalog_service import get_catalog
from ..services.gemini_service import gemini_service
from ..services.recommendation_service import fallback

router = APIRouter(prefix="/api/planners", tags=["Planners"])

UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

ALLOWED_IMAGES = {"image/jpeg", "image/png", "image/webp"}
MAX_UPLOAD = int(os.getenv("MAX_UPLOAD_MB", "5")) * 1024 * 1024


def save_history(db, user_id, planner, request_data, response_data):
    record = RecommendationHistory(
        user_id=user_id,
        planner_type=planner,
        request_json=json.dumps(request_data),
        response_json=json.dumps(response_data),
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def generate(planner, data, user, db, image_bytes=None, image_mime=None):
    catalog = get_catalog(planner)

    result = gemini_service.generate(
        planner=planner,
        data=data,
        catalog=catalog,
        image_bytes=image_bytes,
        image_mime=image_mime,
    )

    if not result:
        result = fallback(planner, data)

    # Guarantee a predictable top-level planner value.
    result["planner"] = planner
    result["budget"] = float(data["budget"])

    save_history(db, user.id, planner, data, result)

    return result


@router.post("/generate-home")
def generate_home(
    payload: HomeRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    data = payload.model_dump()
    return generate("home", data, user, db)


@router.post("/generate-party")
def generate_party(
    payload: PartyRequest,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    data = payload.model_dump()
    return generate("party", data, user, db)


@router.post("/generate-jewelry")
async def generate_jewelry(
    budget: float = Form(...),
    occasion: str = Form("Party"),
    style: str = Form("Elegant"),
    metal: str = Form("Any"),
    outfit_description: str = Form(""),
    outfit_image: UploadFile | None = File(None),
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if budget <= 0:
        raise HTTPException(status_code=422, detail="Budget must be greater than zero")

    image_bytes = None
    image_mime = None
    image_filename = None

    if outfit_image and outfit_image.filename:
        if outfit_image.content_type not in ALLOWED_IMAGES:
            raise HTTPException(
                status_code=400,
                detail="Only JPG, PNG and WEBP images are supported"
            )

        image_bytes = await outfit_image.read()

        if len(image_bytes) > MAX_UPLOAD:
            raise HTTPException(
                status_code=400,
                detail=f"Image must be smaller than {MAX_UPLOAD // (1024 * 1024)} MB"
            )

        safe_name = f"{uuid.uuid4().hex}_{Path(outfit_image.filename).name}"
        target = UPLOAD_DIR / safe_name
        target.write_bytes(image_bytes)

        image_filename = safe_name
        image_mime = outfit_image.content_type

    data = JewelryRequest(
        budget=budget,
        occasion=occasion,
        style=style,
        metal=metal,
        outfit_description=outfit_description,
        image_filename=image_filename,
    ).model_dump()

    return generate(
        "jewelry",
        data,
        user,
        db,
        image_bytes=image_bytes,
        image_mime=image_mime,
    )


@router.get("/history")
def history(
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    records = (
        db.query(RecommendationHistory)
        .filter(RecommendationHistory.user_id == user.id)
        .order_by(RecommendationHistory.created_at.desc())
        .all()
    )

    return [
        {
            "id": item.id,
            "planner": item.planner_type,
            "created_at": item.created_at.isoformat(),
            "request": json.loads(item.request_json),
            "response": json.loads(item.response_json),
        }
        for item in records
    ]


@router.get("/history/{history_id}")
def history_detail(
    history_id: int,
    user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    record = (
        db.query(RecommendationHistory)
        .filter(
            RecommendationHistory.id == history_id,
            RecommendationHistory.user_id == user.id,
        )
        .first()
    )

    if not record:
        raise HTTPException(status_code=404, detail="History item not found")

    return {
        "id": record.id,
        "planner": record.planner_type,
        "created_at": record.created_at.isoformat(),
        "request": json.loads(record.request_json),
        "response": json.loads(record.response_json),
    }
