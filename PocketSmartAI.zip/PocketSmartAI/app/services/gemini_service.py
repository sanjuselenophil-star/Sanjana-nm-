import json
import os
from typing import Optional

from dotenv import load_dotenv

load_dotenv()

try:
    from google import genai
    from google.genai import types
except Exception:
    genai = None
    types = None


class GeminiService:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "").strip()
        self.model = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
        self.client = None

        if self.api_key and genai:
            self.client = genai.Client(api_key=self.api_key)

    @property
    def enabled(self):
        return self.client is not None

    def _prompt(self, planner: str, data: dict, catalog: list) -> str:
        return f"""
You are PocketSmart AI, a budget recommendation assistant.

Planner: {planner}
User input:
{json.dumps(data, indent=2)}

Available catalog examples:
{json.dumps(catalog, indent=2)}

Rules:
1. Stay within the user's total budget.
2. Do not invent exact prices for catalog items.
3. You may explain that catalog values are sample/reference prices.
4. Return ONLY valid JSON.
5. Use this exact structure:

{{
  "planner": "{planner}",
  "budget": number,
  "summary": "short explanation",
  "allocations": {{
      "category": number
  }},
  "recommendations": [
    {{
      "category": "string",
      "name": "string",
      "description": "string",
      "price": number,
      "platform": "string",
      "url": "string"
    }}
  ]
}}

Choose relevant catalog items. Keep recommendations practical and concise.
"""

    def generate(self, planner: str, data: dict, catalog: list,
                 image_bytes: Optional[bytes] = None,
                 image_mime: Optional[str] = None):
        if not self.enabled:
            return None

        prompt = self._prompt(planner, data, catalog)

        try:
            contents = [prompt]

            if image_bytes and types:
                contents.append(
                    types.Part.from_bytes(
                        data=image_bytes,
                        mime_type=image_mime or "image/jpeg"
                    )
                )

            response = self.client.models.generate_content(
                model=self.model,
                contents=contents,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json"
                ) if types else None
            )

            text = response.text.strip()

            if text.startswith("```"):
                text = text.replace("```json", "").replace("```", "").strip()

            return json.loads(text)

        except Exception as exc:
            print("Gemini error:", exc)
            return None


gemini_service = GeminiService()
