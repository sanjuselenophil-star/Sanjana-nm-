from urllib.parse import quote_plus


MOCK_CATALOG = [
    # Home
    {"category": "Lighting", "name": "Minimal LED Ceiling Light",
     "description": "Modern energy-efficient ceiling light.", "price": 1499,
     "platform": "IKEA"},
    {"category": "Fan", "name": "Smart Ceiling Fan",
     "description": "Energy-efficient ceiling fan for bedrooms and living rooms.", "price": 3299,
     "platform": "Amazon"},
    {"category": "Furniture", "name": "Compact 4-Seater Dining Table",
     "description": "Space-saving dining table for apartments.", "price": 8999,
     "platform": "Flipkart"},
    {"category": "Decor", "name": "Set of 3 Wall Art Frames",
     "description": "Neutral wall art set for living rooms.", "price": 1299,
     "platform": "Amazon"},
    {"category": "Storage", "name": "Modular Storage Cabinet",
     "description": "Multi-purpose storage cabinet.", "price": 5499,
     "platform": "IKEA"},

    # Party
    {"category": "Catering", "name": "Standard Party Meal Package",
     "description": "Mixed menu package suitable for small events.", "price": 450,
     "platform": "Zomato"},
    {"category": "Catering", "name": "Vegetarian Party Meal Package",
     "description": "Vegetarian event meal package.", "price": 380,
     "platform": "Swiggy"},
    {"category": "Decoration", "name": "Birthday Decoration Kit",
     "description": "Balloons, banner and table decoration kit.", "price": 1599,
     "platform": "Amazon"},
    {"category": "Venue", "name": "Budget Event Stay",
     "description": "Sample accommodation/venue option.", "price": 3500,
     "platform": "OYO"},
    {"category": "Entertainment", "name": "Basic DJ Setup",
     "description": "Budget-friendly DJ and speaker setup.", "price": 6000,
     "platform": "Local Vendor"},

    # Jewelry
    {"category": "Necklace", "name": "Elegant Gold-Tone Necklace",
     "description": "Occasion-friendly necklace with a minimal finish.", "price": 1799,
     "platform": "Amazon"},
    {"category": "Earrings", "name": "Pearl Drop Earrings",
     "description": "Classic pearl-style earrings.", "price": 899,
     "platform": "Flipkart"},
    {"category": "Bracelet", "name": "Minimal Charm Bracelet",
     "description": "Lightweight bracelet for party and casual outfits.", "price": 699,
     "platform": "Amazon"},
    {"category": "Bangles", "name": "Traditional Bangle Set",
     "description": "Decorative bangle set for festive occasions.", "price": 1299,
     "platform": "Flipkart"},
]


def platform_url(platform: str, query: str) -> str:
    q = quote_plus(query)

    base = {
        "Amazon": f"https://www.amazon.in/s?k={q}",
        "Flipkart": f"https://www.flipkart.com/search?q={q}",
        "IKEA": f"https://www.ikea.com/in/en/search/?q={q}",
        "Swiggy": f"https://www.swiggy.com/search?query={q}",
        "Zomato": f"https://www.zomato.com/search?query={q}",
        "OYO": f"https://www.oyorooms.com/search?location={q}",
    }

    return base.get(platform, f"https://www.google.com/search?q={q}")


def get_catalog(planner: str):
    if planner == "home":
        return [x for x in MOCK_CATALOG if x["category"] in
                {"Lighting", "Fan", "Furniture", "Decor", "Storage"}]

    if planner == "party":
        return [x for x in MOCK_CATALOG if x["category"] in
                {"Catering", "Decoration", "Venue", "Entertainment"}]

    return [x for x in MOCK_CATALOG if x["category"] in
            {"Necklace", "Earrings", "Bracelet", "Bangles"}]


def attach_urls(items):
    result = []
    for item in items:
        copy = dict(item)
        copy["url"] = platform_url(copy["platform"], copy["name"])
        result.append(copy)
    return result
