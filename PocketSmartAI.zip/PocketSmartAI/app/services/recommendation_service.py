from .catalog_service import get_catalog, attach_urls


def budget_safe_items(planner: str, budget: float, limit: int = 8):
    catalog = get_catalog(planner)
    # Keep the examples affordable enough to combine.
    sorted_items = sorted(catalog, key=lambda x: x["price"])
    result = []
    running = 0

    for item in sorted_items:
        if running + item["price"] <= budget:
            result.append(item)
            running += item["price"]
        if len(result) >= limit:
            break

    if not result:
        result = sorted_items[:limit]

    return attach_urls(result)


def fallback_home(data):
    budget = data["budget"]
    items = budget_safe_items("home", budget)

    return {
        "planner": "home",
        "budget": budget,
        "summary": (
            f"A practical home setup for a budget of ₹{budget:,.0f}, "
            "prioritising essential furniture, lighting and decor."
        ),
        "allocations": {
            "furniture": round(budget * 0.40, 2),
            "lighting": round(budget * 0.20, 2),
            "decor": round(budget * 0.15, 2),
            "storage": round(budget * 0.15, 2),
            "buffer": round(budget * 0.10, 2),
        },
        "recommendations": items,
    }


def fallback_party(data):
    budget = data["budget"]
    guests = data["guests"]

    catering = min(budget * 0.40, guests * 450)
    decoration = budget * 0.15
    entertainment = budget * 0.20
    venue = budget * 0.15
    buffer = budget - catering - decoration - entertainment - venue

    return {
        "planner": "party",
        "budget": budget,
        "summary": (
            f"A {data['event_type']} plan for {guests} guests with a balanced "
            "allocation across food, venue, decoration and entertainment."
        ),
        "allocations": {
            "catering": round(catering, 2),
            "decoration": round(decoration, 2),
            "entertainment": round(entertainment, 2),
            "venue": round(venue, 2),
            "buffer": round(max(buffer, 0), 2),
        },
        "recommendations": budget_safe_items("party", budget),
    }


def fallback_jewelry(data):
    budget = data["budget"]

    return {
        "planner": "jewelry",
        "budget": budget,
        "summary": (
            f"Jewelry suggestions for a {data['occasion']} occasion in a "
            f"{data['style']} style, staying within approximately ₹{budget:,.0f}."
        ),
        "allocations": {
            "main_piece": round(budget * 0.55, 2),
            "earrings": round(budget * 0.25, 2),
            "additional_piece": round(budget * 0.10, 2),
            "buffer": round(budget * 0.10, 2),
        },
        "recommendations": budget_safe_items("jewelry", budget),
    }


def fallback(planner, data):
    if planner == "home":
        return fallback_home(data)
    if planner == "party":
        return fallback_party(data)
    return fallback_jewelry(data)
