function authHeaders(headers = {}) {
    const token = localStorage.getItem("access_token");
    const result = { ...headers };

    if (token) {
        result["Authorization"] = `Bearer ${token}`;
    }

    return result;
}


async function authFetch(url, options = {}) {
    options.headers = authHeaders(options.headers || {});
    return fetch(url, options);
}


async function logout() {
    try {
        await fetch("/api/auth/logout", {
            method: "POST",
            headers: authHeaders()
        });
    } catch (_) {
        // Continue logout even if the API request fails
    }

    localStorage.removeItem("access_token");

    window.location.href = "/login";
}


function escapeHtml(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


function renderError(message) {
    const result = document.getElementById("result");

    if (!result) return;

    result.innerHTML = `
        <div class="message error">
            ${escapeHtml(message)}
        </div>
    `;
}


function renderRecommendation(data) {
    const result = document.getElementById("result");

    if (!result) return;

    const allocations = Object.entries(data.allocations || {})
        .map(([key, value]) => `
            <div class="allocation">
                <strong>${escapeHtml(key)}</strong>
                <div>₹${Number(value).toLocaleString("en-IN")}</div>
            </div>
        `)
        .join("");

    const recommendations = (data.recommendations || [])
        .map(item => `
            <article class="recommendation">
                <span class="badge">${escapeHtml(item.category)}</span>
                <h3>${escapeHtml(item.name)}</h3>
                <p>${escapeHtml(item.description)}</p>
                <div class="price">
                    ₹${Number(item.price).toLocaleString("en-IN")}
                </div>
                <div class="platform">
                    ${escapeHtml(item.platform)}
                </div>

                <br>

                <a
                    class="btn"
                    target="_blank"
                    rel="noopener noreferrer"
                    href="${escapeHtml(item.url)}"
                >
                    View Platform
                </a>
            </article>
        `)
        .join("");

    result.innerHTML = `
        <div class="result-header">
            <span class="badge">${escapeHtml(data.planner)}</span>

            <h2>Your recommendation plan</h2>

            <p>${escapeHtml(data.summary)}</p>
        </div>

        <h3>Budget allocation</h3>

        <div class="allocations">
            ${allocations}
        </div>

        <h3>Recommendations</h3>

        ${recommendations || "<p>No recommendations returned.</p>"}
    `;
}


document.addEventListener("DOMContentLoaded", async () => {

    const protectedMenu = document.getElementById("protectedMenu");
    const publicMenu = document.getElementById("publicMenu");
    const logoutBtn = document.getElementById("logoutBtn");

    /*
     * By default:
     * Show Register/Login
     * Hide Dashboard/Home/Party/Jewelry/History/Logout
     */

    if (protectedMenu) {
        protectedMenu.classList.add("hidden");
    }

    if (publicMenu) {
        publicMenu.classList.remove("hidden");
    }


    if (logoutBtn) {
        logoutBtn.addEventListener("click", logout);
    }


    /*
     * Check whether the current user is logged in.
     */

    try {

        const response = await authFetch("/api/auth/me");

        if (response.ok) {

            // User is logged in

            if (protectedMenu) {
                protectedMenu.classList.remove("hidden");
            }

            if (publicMenu) {
                publicMenu.classList.add("hidden");
            }

        } else {

            // User is not logged in

            localStorage.removeItem("access_token");

        }

    } catch (_) {

        // User is not logged in
        localStorage.removeItem("access_token");

    }

});